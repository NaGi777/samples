package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;

public class MenuCl {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button viewMenuButtonCl;

    @FXML
    private Button buyMenuButtonCl;

    @FXML
    private Button sellMenuButtonCl;

    @FXML
    private Button informMenuButtonCl;

    @FXML
    private Button chancheUser;

    @FXML
    void initialize() {
        viewMenuButtonCl.setOnAction(even->{

            changeScene("/sample/CarsTabCl.fxml");

        });
        chancheUser.setOnAction(even->{

            changeScene("/sample/sample.fxml");

        });

        sellMenuButtonCl.setOnAction(even->{

            changeScene("/sample/sellCars.fxml");

        });

        buyMenuButtonCl.setOnAction(even->{

            changeScene("/sample/buyCars.fxml");
        });
        informMenuButtonCl.setOnAction(even->{

            changeScene("/sample/infoCl.fxml");
        });




    }

    public void changeScene(String fxml){
        Parent pane = null;
        try {
            pane = FXMLLoader.load(
                    getClass().getResource(fxml));
        } catch (IOException e) {
            e.printStackTrace();
        }
        viewMenuButtonCl.getScene().setRoot(pane);
    }
}

