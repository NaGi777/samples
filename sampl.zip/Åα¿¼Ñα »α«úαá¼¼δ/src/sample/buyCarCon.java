package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class buyCarCon {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField idCar_field;

    @FXML
    private Button buyCarsButton;

    @FXML
    private Button returnButton;

    @FXML
    void initialize() {


        buyCarsButton.setOnAction(even->{
            buyCar();
            changeScene("/sample/MenuCl.fxml");
        });
        returnButton.setOnAction(even->{
            buyCar();
            changeScene("/sample/MenuCl.fxml");
        });

    }

    private void buyCar() {
        DatabaseHandler dbHandler=new DatabaseHandler();
        String id=idCar_field.getText();
        dbHandler.deleteCars( id);
    }


    public void changeScene(String fxml){
        Parent pane = null;
        try {
            pane = FXMLLoader.load(
                    getClass().getResource(fxml));
        } catch (IOException e) {
            e.printStackTrace();
        }
        buyCarsButton.getScene().setRoot(pane);
    }
}
