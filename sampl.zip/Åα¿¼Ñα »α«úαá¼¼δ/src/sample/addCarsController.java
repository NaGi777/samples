package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class addCarsController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField nameCar_field;

    @FXML
    private TextField costCar_field;

    @FXML
    private Button addToCars;

    @FXML
    private Button returnButton;

    @FXML
    void initialize() {
        returnButton.setOnAction(even->{
            changeScene("/sample/Menu.fxml");
        });

        addToCars.setOnAction(even->{
            singUpNewCar();
            changeScene("/sample/Menu.fxml");


        });

    }
    private void singUpNewCar() {
        DatabaseHandler dbHandler=new DatabaseHandler();
        String name=nameCar_field.getText();
        String cost=costCar_field.getText();
        User user =new User(name,cost);
        dbHandler.singUpCars( user);
    }

    public void changeScene(String fxml){
        Parent pane = null;
        try {
            pane = FXMLLoader.load(
                    getClass().getResource(fxml));
        } catch (IOException e) {
            e.printStackTrace();
        }
        returnButton.getScene().setRoot(pane);
    }
}

