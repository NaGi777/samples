package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class TableController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button returnButton;

    @FXML
    private TableView<Cars> tableCars;

    @FXML
    private TableColumn<?, ?> IdCol;

    @FXML
    private TableColumn<?, ?> nameCol;

    @FXML
    private TableColumn<?, ?> costCol;

    @FXML
    void initialize() {
        try {


        DatabaseHandler dbHandler=new DatabaseHandler();
        var resultSet=dbHandler.getCar();

        ObservableList<Cars> data = FXCollections.observableArrayList();

        while (resultSet.next())
        {
            data.add(new Cars(resultSet.getInt(1),resultSet.getString(2),resultSet.getInt(3)));
            // System.out.println(resultSet.getString(1)+" "+resultSet.getString(2)+" "+resultSet.getString((3)) );
        }

      IdCol.setCellValueFactory(new PropertyValueFactory<>("carId"));
      //  TableColumn firstNameCol = new TableColumn("ID");
       // firstNameCol.setMinWidth(100);
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

      //  TableColumn lastNameCol = new TableColumn("Марки");
      //  TableColumn emailCol = new TableColumn("Стоимость");
        costCol.setCellValueFactory(new PropertyValueFactory<>("carCost"));
       // emailCol.setCellValueFactory(new PropertyValueFactory<>("id"));
            tableCars.setItems(data);


            returnButton.setOnAction(even->{

                changeScene("/sample/Menu.fxml");

            });

    }
    catch (Exception e)
    {

    }
    }
    public void changeScene(String fxml) {
        Parent pane = null;
        try {
            pane = FXMLLoader.load(
                    getClass().getResource(fxml));
        } catch (IOException e) {
            e.printStackTrace();
        }
        returnButton.getScene().setRoot(pane);
    }

    }
