package sample;

public class Cars {
    public int carId;
    public int carCost;
    public String name;
Cars(int carId,String name,int carCost){
    this.name=name;
    this.carCost=carCost;
    this.carId=carId;

}
    public String getName() {
        return name;
    }

    public int getCarCost() {
        return carCost;
    }

    public int getCarId() {
        return carId;
    }

}
