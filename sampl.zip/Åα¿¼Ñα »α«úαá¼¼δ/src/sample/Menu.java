package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Menu {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button viewMenuButton;

    @FXML
    private Button deleteMenuButton;

    @FXML
    private Button addMenuButton;

    @FXML
    private Button chancheUser;

    @FXML
    private Button informMenuButton;
    @FXML
    void initialize() {
        viewMenuButton.setOnAction(even->{

        changeScene("/sample/CarsTable.fxml");

    });
        chancheUser.setOnAction(even->{

            changeScene("/sample/sample.fxml");

        });

        addMenuButton.setOnAction(even->{

            changeScene("/sample/addCars.fxml");

        });

        deleteMenuButton.setOnAction(even->{

            changeScene("/sample/deleteCars.fxml");
        });
        informMenuButton.setOnAction(even->{

            changeScene("/sample/infoAuto.fxml");
        });




    }

    public void changeScene(String fxml){
        Parent pane = null;
        try {
            pane = FXMLLoader.load(
                    getClass().getResource(fxml));
        } catch (IOException e) {
            e.printStackTrace();
        }
        viewMenuButton.getScene().setRoot(pane);
    }
    }
