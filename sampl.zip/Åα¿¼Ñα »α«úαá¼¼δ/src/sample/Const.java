package sample;

public class Const {
    public static final String USER_TABLE="users";
    public static final String CARS_TABLE="auto";
    public static final String USER_ID="idusers";
    public static final String USER_LOGIN="login";
    public static final String USER_PASSWORD="password";
    public static final String CARS_NAME="name";
    public static final String CARS_COST="cost";
    public static final String CARS_ID="id";
    public static final String CL_TABLE="clients";
    public static final String CL_LOGIN="loginCl";
    public static final String CL_PASSWORD="passwordCl";
}
