package sample;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class Main extends Application {




    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Автосалон");
        primaryStage.setScene(new Scene(root, 700, 400));
        primaryStage.show();
    }


    public static void main(String[] args) {



        try{
            Socket s = new Socket();
            try {
                s.connect(new InetSocketAddress(InetAddress.getLocalHost(), 7777));
                 Scanner fromServer = new Scanner(s.getInputStream());
               System.out.println(fromServer.next());
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }

        }
        catch(Exception e)
        {

        }
        launch(args);
    }
}

