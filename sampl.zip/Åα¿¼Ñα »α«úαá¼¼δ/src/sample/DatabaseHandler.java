package sample;
import java.sql.*;

public class DatabaseHandler extends Configs {
    Connection dbConnection;
    public Connection getDbConnection()throws ClassNotFoundException,SQLException
    {
        String connectionString="jdbc:mysql://"+dbHost+":"+
               dbPort+"/"+dbName+"?";
        dbConnection=DriverManager.getConnection(connectionString,dbUser,dbPass);
        return dbConnection;
    }
    public void singUpUsers(User user){
        String insert="INSERT INTO "+Const.USER_TABLE+"("+Const.USER_LOGIN+","+Const.USER_PASSWORD+")"+"VALUES(?,?)";

        try {
            PreparedStatement prSt= getDbConnection().prepareStatement(insert);
            prSt.setString(1,user.getLogin());
            prSt.setString(2,user.getPassword());
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void singUpCl(User user){
        String insert="INSERT INTO "+Const.CL_TABLE+"("+Const.CL_LOGIN+","+Const.CL_PASSWORD+")"+"VALUES(?,?)";

        try {
            PreparedStatement prSt= getDbConnection().prepareStatement(insert);
            prSt.setString(1,user.getLogin());
            prSt.setString(2,user.getPassword());
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }




    public void singUpCars(User user){
        String insert="INSERT INTO "+Const.CARS_TABLE+"("+Const.CARS_NAME+","+Const.CARS_COST+")"+"VALUES(?,?)";

        try {
            PreparedStatement prSt= getDbConnection().prepareStatement(insert);
            prSt.setString(1,user.getLogin());
            prSt.setString(2,user.getPassword());
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void deleteCars(String carId){
        String insert="DELETE FROM "+Const.CARS_TABLE+" WHERE "+Const.CARS_ID+" = "+carId;
System.out.println(carId);
        try {
            PreparedStatement prSt= getDbConnection().prepareStatement(insert);
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public ResultSet getUser(User user)
{
    ResultSet resSet=null;
    String select="SELECT * FROM "+ Const.USER_TABLE+ " WHERE "+Const.USER_LOGIN+"=? AND "+Const.USER_PASSWORD+ "=?";
    try {
        PreparedStatement prSt= getDbConnection().prepareStatement(select);
        prSt.setString(1,user.getLogin());
        prSt.setString(2,user.getPassword());
       resSet= prSt.executeQuery();
    } catch (SQLException e) {
        e.printStackTrace();
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }
    return resSet;
}


    public ResultSet getCl(User user)
    {
        ResultSet resSet=null;
        String select="SELECT * FROM "+ Const.CL_TABLE+ " WHERE "+Const.CL_LOGIN+"=? AND "+Const.CL_PASSWORD+ "=?";
        try {
            PreparedStatement prSt= getDbConnection().prepareStatement(select);
            prSt.setString(1,user.getLogin());
            prSt.setString(2,user.getPassword());
            resSet= prSt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return resSet;
    }

public  ResultSet getCar(){
        ResultSet resSet=null;

    try {
        PreparedStatement prSt= getDbConnection().prepareStatement("SELECT*FROM auto ");

 resSet=prSt.executeQuery();
    }
    catch (SQLException throwables) {
        throwables.printStackTrace();
    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }
    return resSet;
}
}
