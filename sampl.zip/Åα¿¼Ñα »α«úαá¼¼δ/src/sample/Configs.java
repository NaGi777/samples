package sample;

public class Configs {
    protected String dbHost="localhost";
    protected String dbPort="3306";
    protected String dbUser="root";
    protected String dbPass="root";
    protected String dbName="kursach";
}
