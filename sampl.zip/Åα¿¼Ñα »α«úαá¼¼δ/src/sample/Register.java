package sample;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Register {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField login_field;

    @FXML
    private PasswordField password_field;

    @FXML
    private Button SingUpButton;

    @FXML
    private Button SingUpButtonCL;

    @FXML
    void initialize() {



        SingUpButtonCL.setOnAction(even->{
            singUpNewCl();
            changeScene("/sample/sample.fxml");


        });

        SingUpButton.setOnAction(even->{
            singUpNewUser();
            changeScene("/sample/sample.fxml");


        });


    }

    private void singUpNewUser() {
        DatabaseHandler dbHandler=new DatabaseHandler();
        String login=login_field.getText();
        String password=password_field.getText();
        User user =new User(login,password);
        dbHandler.singUpUsers( user);
    }

    private void singUpNewCl() {
        DatabaseHandler dbHandler=new DatabaseHandler();
        String login=login_field.getText();
        String password=password_field.getText();
        User user =new User(login,password);
        dbHandler.singUpCl( user);
    }
    public void changeScene(String fxml){
        Parent pane = null;
        try {
            pane = FXMLLoader.load(
                    getClass().getResource(fxml));
        } catch (IOException e) {
            e.printStackTrace();
        }

        SingUpButton.getScene().setRoot(pane);
    }
}